# operations.py

# This module contains the core operational logic of the inventory system.
# It includes functions for displaying products, processing sales and restocks,
# and adding new products to the inventory. It uses functions from the 'write'
# module to save invoices.

from datetime import datetime # Used for getting current date and time for invoices
import write                 # To use functions for saving invoices and product data

# <-------------------- Helper Function for Manual Padding -------------------->
def manual_pad_string(input_string, target_width, fill_char=" "):
    """
    Manually pads a string on the right with a fill character to achieve a target width.
    This function is a replacement for the built-in string.ljust() method.

    Logic:
    1. Calculate the current length of the input string.
    2. Determine how many padding characters are needed to reach the target_width.
    3. If padding is needed (padding_needed > 0):
       a. Start with the original string.
       b. Append the fill_char repeatedly until the target_width is met.
    4. If the input_string is already longer than or equal to target_width, it's
       returned as is (or could be truncated in a more complex version).

    Args:
        input_string (str): The string that needs to be padded.
        target_width (int): The desired total width of the resulting string.
        fill_char (str, optional): The character to use for padding. Defaults to a space.

    Returns:
        str: The padded string.
    """
    current_length = len(input_string)
    padding_needed = target_width - current_length
    
    padded_string = input_string # Initialize with the original string
    
    if padding_needed > 0:
        # Loop 'padding_needed' times to add the fill character
        for _ in range(padding_needed):
            padded_string = padded_string + fill_char # Concatenate the fill character
            
    # Note: If input_string is longer than target_width, this implementation
    # returns the original string without truncation. For display, this might
    # disrupt alignment. A more robust solution might truncate or handle differently.
    return padded_string

# <-------------------- Helper Function for Two-Digit Formatting -------------------->
def format_to_two_digits(number):
    """
    Formats an integer into a two-digit string, prepending a '0' if the number is < 10.
    Useful for formatting months, days, hours, minutes, and seconds consistently.

    Logic:
    1. Check if the input number is less than 10.
    2. If it is, convert the number to a string and prepend "0".
    3. Otherwise, just convert the number to a string.

    Args:
        number (int): The integer to format.

    Returns:
        str: The two-digit string representation of the number.
    """
    if number < 10:
        return "0" + str(number) # e.g., 5 becomes "05"
    else:
        return str(number)       # e.g., 12 becomes "12"

# <-------------------- Define Column Widths for Display and Invoices -------------------->
# These constants define the fixed width for each column in tabular displays
# and invoices, helping to maintain a consistent layout.
COL_WIDTH_ID = 5
COL_WIDTH_PRODUCT_NAME = 25
COL_WIDTH_BRAND = 15
COL_WIDTH_STOCK_QTY = 10  # Used for various quantity columns
COL_WIDTH_PRICE_COST = 15 # Used for various price/cost columns

# <-------------------- Display Products Information -------------------->
def display_products_info(products_list):
    """
    Displays a formatted table of available products to the console.
    Selling price is calculated as 3 times the cost price (200% markup).

    Logic:
    1. Prints a main header for the product table.
    2. Constructs and prints a column header row using manual_pad_string for alignment.
    3. Prints a separator line (e.g., "----") based on the header's length.
    4. If no products are available, prints a message.
    5. Iterates through each product in the products_list:
       a. Calculates the selling price.
       b. Formats each piece of product information (ID, name, brand, stock,
          selling price, origin) using manual_pad_string to fit column widths.
       c. Concatenates these formatted strings and prints the product row.
    6. Prints a final separator line.
    """
    print("\n------------------------------------- Available Products --------------------------------------")
    
    # Constructing the header row using manual padding for each column title
    header_id = manual_pad_string("ID", COL_WIDTH_ID)
    header_name = manual_pad_string("Product Name", COL_WIDTH_PRODUCT_NAME)
    header_brand = manual_pad_string("Brand", COL_WIDTH_BRAND)
    header_stock = manual_pad_string("Stock", COL_WIDTH_STOCK_QTY)
    header_price = manual_pad_string("Selling Price", COL_WIDTH_PRICE_COST)
    header_origin = manual_pad_string("Origin", COL_WIDTH_BRAND) # Reusing a width for consistency

    full_header = header_id + header_name + header_brand + header_stock + header_price + header_origin
    print(full_header)
    
    # Dynamically create a separator line based on the total length of the header
    separator_line = ""
    for _ in range(len(full_header)):
        separator_line += "-"
    print(separator_line)

    if not products_list: # Check if the product list is empty
        print(manual_pad_string("No products available to display.", len(full_header)))
        print(separator_line)
        return # Exit the function if no products

    # Loop through each product dictionary in the list
    for p_dict in products_list:
        selling_price = p_dict['cost'] * 3 # Calculate selling price (200% markup)
        
        # Format each product attribute string for display
        id_str = manual_pad_string(str(p_dict['id']), COL_WIDTH_ID)
        name_str = manual_pad_string(p_dict['name'], COL_WIDTH_PRODUCT_NAME)
        brand_str = manual_pad_string(p_dict['brand'], COL_WIDTH_BRAND)
        stock_str = manual_pad_string(str(p_dict['stock']), COL_WIDTH_STOCK_QTY)
        price_str = manual_pad_string("Rs. " + str(int(selling_price)), COL_WIDTH_PRICE_COST) # Display integer part
        origin_str = manual_pad_string(p_dict['origin'], COL_WIDTH_BRAND)
        
        # Print the formatted product row
        print(id_str + name_str + brand_str + stock_str + price_str + origin_str)
    print(separator_line) # Print a final separator


# <-------------------- Process Customer Sale -------------------->
def process_customer_sale(products_data):
    """
    Manages the entire sales transaction for a customer.

    Logic:
    1. Prompts for the customer's name.
    2. Enters a loop allowing the customer to add multiple products to their cart:
       a. Displays available products.
       b. Asks for a product ID to purchase.
       c. Validates the ID and checks if the product exists.
       d. Asks for the quantity to purchase and validates it.
       e. Calculates 'Buy 3 Get 1 Free':
          - `free_items_earned` = `quantity_to_buy` // 3
          - `total_items_to_deduct` from stock = `quantity_to_buy` + `free_items_earned`
       f. Checks if sufficient stock is available for `total_items_to_deduct`.
       g. If stock is sufficient:
          - Updates the product's stock in `products_data`.
          - Adds the item details (including paid and free quantities, unit price,
            and line total for paid items) to a `cart_items` list.
          - Adds the line total to `subtotal_before_discount_and_vat`.
       h. If stock is insufficient, informs the customer.
    3. After the customer finishes shopping (enters 'done'):
       a. If the cart is empty, the transaction is cancelled.
       b. Calculates a 10% discount if `subtotal_before_discount_and_vat` > 1000.
       c. Calculates a 13% VAT on the subtotal (after any discount).
       d. Calculates the final `grand_total_bill`.
    4. Generates a unique invoice filename and timestamp using manual date/time formatting.
    5. Prepares a list of strings (`invoice_lines`) for the invoice content, including:
       - Header (customer name, date).
       - Table of purchased items (ID, Product, Brand, Qty Paid, Free Qty, Unit Price, Line Total).
       - Footer (Subtotal before discount, Discount, Subtotal after discount, VAT, Grand Total).
       - All invoice formatting uses `manual_pad_string`.
    6. Prints the invoice to the console.
    7. Calls `write.generate_transaction_invoice` to save the invoice to a file.
    """
    customer_name = input("Enter customer name: ")
    cart_items = [] 
    subtotal_before_discount_and_vat = 0.0 

    while True: 
        display_products_info(products_data)
        try:
            product_id_input = input("\nEnter product ID to buy (or type 'done' to finish shopping): ")
            if product_id_input.lower() == 'done':
                break 
            selected_product_id = int(product_id_input)
            product_found = None
            for p_dict in products_data:
                if p_dict['id'] == selected_product_id:
                    product_found = p_dict
                    break
            if product_found:
                print("Selected: " + product_found['name'] + " (Stock: " + str(product_found['stock']) + ")")
                quantity_to_buy = int(input("Enter quantity you wish to purchase: "))
                if quantity_to_buy <= 0:
                    print("Invalid quantity. Please enter a positive number.")
                    continue
                free_items_earned = quantity_to_buy // 3
                total_items_to_deduct = quantity_to_buy + free_items_earned
                selling_price_per_item = product_found['cost'] * 3
                cost_for_this_item_line = quantity_to_buy * selling_price_per_item
                if product_found['stock'] >= total_items_to_deduct:
                    product_found['stock'] -= total_items_to_deduct 
                    cart_items.append({
                        'id': product_found['id'], 'name': product_found['name'],
                        'brand': product_found['brand'], 'qty_paid': quantity_to_buy,
                        'free_qty': free_items_earned, 'unit_price': selling_price_per_item,
                        'line_total': cost_for_this_item_line
                    })
                    subtotal_before_discount_and_vat += cost_for_this_item_line
                    print(str(quantity_to_buy) + " " + product_found['name'] + "(s) added to cart.")
                    if free_items_earned > 0:
                        print("You get " + str(free_items_earned) + " " + product_found['name'] + "(s) for free!")
                else:
                    print("Sorry, insufficient stock for " + product_found['name'] + " to fulfill the 'Buy 3 Get 1 Free' offer for " + str(quantity_to_buy) + " items.")
            else:
                print("Product ID not found. Please try again.")
        except ValueError:
            print("Invalid input. Please enter a valid number for ID or quantity.")
        except Exception as e: # Catch any other unexpected error during sale processing
            print("An error occurred during the sale process: " + str(e))

    if not cart_items:
        print("No items were purchased. Transaction cancelled.")
        return

    # --- Calculate Discount and VAT ---
    discount_amount = 0.0
    discount_percentage_str = "0%" 
    if subtotal_before_discount_and_vat > 1000:
        discount_amount = subtotal_before_discount_and_vat * 0.10 # 10% discount
        discount_percentage_str = "10%"
        print("\nNote: A " + discount_percentage_str + " discount is applied as subtotal exceeds Rs. 1000.")
    subtotal_after_discount = subtotal_before_discount_and_vat - discount_amount
    vat_percentage = 0.13 
    vat_amount = subtotal_after_discount * vat_percentage
    grand_total_bill = subtotal_after_discount + vat_amount

    # --- Manually Format Date and Time for Invoice ---
    now = datetime.now()
    year_str = str(now.year)
    month_str = format_to_two_digits(now.month)
    day_str = format_to_two_digits(now.day)
    hour_str = format_to_two_digits(now.hour)
    minute_str = format_to_two_digits(now.minute)
    second_str = format_to_two_digits(now.second)
    transaction_datetime_str = year_str + "-" + month_str + "-" + day_str + " " + \
                               hour_str + ":" + minute_str + ":" + second_str
    invoice_file_datetime_str = year_str + month_str + day_str + "_" + \
                                hour_str + minute_str + second_str
    safe_customer_name = customer_name.replace(" ", "_") # Simple space replacement for filename
    invoice_filename = "sale_invoice_" + safe_customer_name + "_" + invoice_file_datetime_str + ".txt"
    
    # --- Prepare Invoice Content ---
    invoice_lines = []
    invoice_lines.append("==================== WeCare Sales Invoice ====================")
    invoice_lines.append("Customer: " + customer_name)
    invoice_lines.append("Date: " + transaction_datetime_str)
    invoice_lines.append("--------------------------------------------------------------")
    # Invoice items header
    inv_h_id = manual_pad_string("ID", COL_WIDTH_ID)
    inv_h_name = manual_pad_string("Product", COL_WIDTH_PRODUCT_NAME)
    inv_h_brand = manual_pad_string("Brand", COL_WIDTH_BRAND)
    inv_h_qty_paid = manual_pad_string("Qty Paid", COL_WIDTH_STOCK_QTY)
    inv_h_free_qty = manual_pad_string("Free Qty", COL_WIDTH_STOCK_QTY)
    inv_h_unit_price = manual_pad_string("Unit Price", COL_WIDTH_PRICE_COST)
    inv_h_total = manual_pad_string("Line Total", COL_WIDTH_PRICE_COST) # Line total (qty_paid * unit_price)
    invoice_header_line = inv_h_id + inv_h_name + inv_h_brand + inv_h_qty_paid + inv_h_free_qty + inv_h_unit_price + inv_h_total
    invoice_lines.append(invoice_header_line)
    separator_line_invoice = ""
    for _ in range(len(invoice_header_line)): separator_line_invoice += "-"
    invoice_lines.append(separator_line_invoice)
    # Invoice items
    for item in cart_items:
        line_id = manual_pad_string(str(item['id']), COL_WIDTH_ID)
        line_name = manual_pad_string(item['name'], COL_WIDTH_PRODUCT_NAME)
        line_brand = manual_pad_string(item['brand'], COL_WIDTH_BRAND)
        line_qty_paid = manual_pad_string(str(item['qty_paid']), COL_WIDTH_STOCK_QTY)
        line_free_qty = manual_pad_string(str(item['free_qty']), COL_WIDTH_STOCK_QTY)
        line_unit_price = manual_pad_string("Rs." + str(int(item['unit_price'])), COL_WIDTH_PRICE_COST)
        line_total_val = manual_pad_string("Rs." + str(int(item['line_total'])), COL_WIDTH_PRICE_COST)
        invoice_lines.append(line_id + line_name + line_brand + line_qty_paid + line_free_qty + line_unit_price + line_total_val)
    invoice_lines.append(separator_line_invoice)
    # Invoice footer calculations
    def format_footer_line(label, value_str, total_width):
        padding = total_width - len(label) - len(value_str)
        padded_label = label
        if padding > 0:
            for _ in range(padding): padded_label = padded_label + " "
        return padded_label + value_str

    invoice_lines.append(format_footer_line("Subtotal (before discount):", "Rs. " + str(int(subtotal_before_discount_and_vat)), len(invoice_header_line)))
    invoice_lines.append(format_footer_line("Discount (" + discount_percentage_str + "):", "- Rs. " + str(int(discount_amount)), len(invoice_header_line)))
    invoice_lines.append(format_footer_line("Subtotal (after discount):", "Rs. " + str(int(subtotal_after_discount)), len(invoice_header_line)))
    invoice_lines.append(format_footer_line("VAT (13%):", "+ Rs. " + str(int(vat_amount)), len(invoice_header_line)))
    invoice_lines.append(separator_line_invoice)
    invoice_lines.append(format_footer_line("GRAND TOTAL (Payable):", "Rs. " + str(int(grand_total_bill)), len(invoice_header_line)))
    invoice_lines.append("================ Thank you for shopping with WeCare! ===========")

    # --- Print and Save Invoice ---
    print("\n--- Sales Invoice ---")
    for line_val in invoice_lines: print(line_val)
    write.generate_transaction_invoice(invoice_filename, invoice_lines)


# <-------------------- Process Shop Restock -------------------->
def process_shop_restock(products_data):
    """
    Manages the process of restocking products from a supplier.

    Logic:
    1. Prompts for the supplier's name.
    2. Enters a loop allowing multiple products to be restocked:
       a. Displays available products (to choose which one to restock).
       b. Asks for a product ID to restock.
       c. Validates ID and checks if the product exists.
       d. Asks for the quantity to add and the new cost price from the supplier.
       e. Validates quantity and new cost price.
       f. Updates the product's stock and cost price in `products_data`.
       g. Adds details of the restocked item (ID, name, brand, quantity added,
          unit cost, line total cost) to a `restock_cart` list.
       h. Adds the line total cost to `grand_total_restock_cost`.
    3. After restocking is finished (user enters 'done'):
       a. If no items were restocked, the transaction is cancelled.
    4. Generates a unique restock invoice filename and timestamp using manual
       date/time formatting.
    5. Prepares `invoice_lines` for the restock invoice, including:
       - Header (supplier name, date).
       - Table of restocked items (ID, Product, Brand, Qty Added, Unit Cost, Total Cost).
       - Footer (Total Restock Cost).
       - All invoice formatting uses `manual_pad_string`.
    6. Prints the restock invoice to the console.
    7. Calls `write.generate_transaction_invoice` to save the invoice to a file.
    
    Note: Sales discounts and VAT are NOT applied to restock operations.
    """
    supplier_name = input("Enter supplier name: ")
    restock_cart = []
    grand_total_restock_cost = 0.0

    while True: 
        display_products_info(products_data)
        try:
            product_id_input = input("\nEnter product ID to restock (or type 'done' to finish): ")
            if product_id_input.lower() == 'done':
                break
            selected_product_id = int(product_id_input)
            product_found = None
            for p_dict in products_data:
                if p_dict['id'] == selected_product_id:
                    product_found = p_dict
                    break
            if product_found:
                print("Selected for restock: " + product_found['name'] + " (Current Stock: " + \
                      str(product_found['stock']) + ", Current Cost: Rs." + str(product_found['cost']) + ")")
                quantity_to_add = int(input("Enter quantity to add: "))
                if quantity_to_add <= 0:
                    print("Invalid quantity. Must be positive.")
                    continue
                new_cost_price = float(input("Enter new cost price per item from supplier (current is Rs." + \
                                           str(product_found['cost']) + "): "))
                if new_cost_price < 0:
                    print("Invalid cost price. Cannot be negative.")
                    continue
                product_found['stock'] += quantity_to_add
                product_found['cost'] = new_cost_price # Update product's cost price
                line_total_cost = quantity_to_add * new_cost_price
                restock_cart.append({
                    'id': product_found['id'], 'name': product_found['name'],
                    'brand': product_found['brand'], 'qty_added': quantity_to_add,
                    'unit_cost': new_cost_price, 'line_total': line_total_cost
                })
                grand_total_restock_cost += line_total_cost
                print(str(quantity_to_add) + " " + product_found['name'] + "(s) restocked.")
            else:
                print("Product ID not found.")
        except ValueError:
            print("Invalid input for ID, quantity, or price.")
        except Exception as e: # Catch other errors
            print("An error occurred during restocking: " + str(e))

    if not restock_cart:
        print("No products were restocked. Transaction cancelled.")
        return

    # --- Manually Format Date and Time for Restock Invoice ---
    now = datetime.now()
    year_str = str(now.year); month_str = format_to_two_digits(now.month); day_str = format_to_two_digits(now.day)
    hour_str = format_to_two_digits(now.hour); minute_str = format_to_two_digits(now.minute); second_str = format_to_two_digits(now.second)
    transaction_datetime_str = year_str + "-" + month_str + "-" + day_str + " " + hour_str + ":" + minute_str + ":" + second_str
    invoice_file_datetime_str = year_str + month_str + day_str + "_" + hour_str + minute_str + second_str
    safe_supplier_name = supplier_name.replace(" ", "_")
    invoice_filename = "restock_invoice_" + safe_supplier_name + "_" + invoice_file_datetime_str + ".txt"
    
    # --- Prepare Restock Invoice Content ---
    invoice_lines = []
    invoice_lines.append("=================== WeCare Restock Invoice ===================")
    invoice_lines.append("Supplier: " + supplier_name)
    invoice_lines.append("Date: " + transaction_datetime_str)
    invoice_lines.append("--------------------------------------------------------------")
    # Restock items header
    restock_h_id = manual_pad_string("ID", COL_WIDTH_ID)
    restock_h_name = manual_pad_string("Product", COL_WIDTH_PRODUCT_NAME)
    restock_h_brand = manual_pad_string("Brand", COL_WIDTH_BRAND)
    restock_h_qty_added = manual_pad_string("Qty Added", COL_WIDTH_STOCK_QTY)
    restock_h_unit_cost = manual_pad_string("Unit Cost", COL_WIDTH_PRICE_COST)
    restock_h_total_cost = manual_pad_string("Total Cost", COL_WIDTH_PRICE_COST)
    restock_header_line = restock_h_id + restock_h_name + restock_h_brand + restock_h_qty_added + restock_h_unit_cost + restock_h_total_cost
    invoice_lines.append(restock_header_line)
    restock_separator_line = ""; 
    for _ in range(len(restock_header_line)): restock_separator_line += "-"
    invoice_lines.append(restock_separator_line)
    # Restock items
    for item in restock_cart:
        line_id = manual_pad_string(str(item['id']), COL_WIDTH_ID)
        line_name = manual_pad_string(item['name'], COL_WIDTH_PRODUCT_NAME)
        line_brand = manual_pad_string(item['brand'], COL_WIDTH_BRAND)
        line_qty_added = manual_pad_string(str(item['qty_added']), COL_WIDTH_STOCK_QTY)
        line_unit_cost = manual_pad_string("Rs." + str(int(item['unit_cost'])), COL_WIDTH_PRICE_COST)
        line_total_val = manual_pad_string("Rs." + str(int(item['line_total'])), COL_WIDTH_PRICE_COST)
        invoice_lines.append(line_id + line_name + line_brand + line_qty_added + line_unit_cost + line_total_val)
    invoice_lines.append(restock_separator_line)
    # Restock footer (total cost)
    def format_footer_line(label, value_str, total_width): # Re-using helper defined in sales for consistency
        padding = total_width - len(label) - len(value_str)
        padded_label = label
        if padding > 0:
            for _ in range(padding): padded_label = padded_label + " "
        return padded_label + value_str
    invoice_lines.append(format_footer_line("TOTAL RESTOCK COST:", "Rs. " + str(int(grand_total_restock_cost)), len(restock_header_line)))
    invoice_lines.append("==============================================================")

    # --- Print and Save Restock Invoice ---
    print("\n--- Restock Invoice ---")
    for line_val in invoice_lines: print(line_val)
    write.generate_transaction_invoice(invoice_filename, invoice_lines)


# <-------------------- Add New Product to Inventory -------------------->
def add_new_product_to_inventory(products_data):
    """
    Allows the user to add a brand-new product to the inventory.

    Logic:
    1. Prompts the user for the new product's details: name, brand, initial stock,
       cost price, and origin country.
    2. Performs basic validation for stock and cost (must be non-negative).
    3. Generates a new unique ID for the product:
       - If the `products_data` list is empty, the new ID starts at 101.
       - Otherwise, it finds the maximum existing ID in `products_data` and adds 1.
    4. Creates a new product dictionary with the collected details and the new ID.
    5. Appends this new product dictionary to the `products_data` list.
    6. Confirms to the user that the product has been added.
    7. Includes a try-except block to catch potential errors during input or processing.
    """
    print("\n--- Add New Product to Inventory ---")
    try:
        product_name = input("Enter new product name: ")
        product_brand = input("Enter product brand: ")
        # Loop for valid stock input
        while True:
            try:
                product_stock = int(input("Enter initial stock quantity: "))
                if product_stock >= 0:
                    break
                else:
                    print("Stock quantity cannot be negative. Please re-enter.")
            except ValueError:
                print("Invalid input for stock. Please enter a whole number.")
        # Loop for valid cost input
        while True:
            try:
                product_cost = float(input("Enter cost price per item: "))
                if product_cost >= 0:
                    break
                else:
                    print("Cost price cannot be negative. Please re-enter.")
            except ValueError:
                print("Invalid input for cost. Please enter a number.")
        product_origin = input("Enter country of origin: ")

        # Generate a new unique ID for the product
        new_id = 101 # Default ID if no products exist
        if products_data: # If there are existing products
            max_id = 0
            for p_dict in products_data:
                if p_dict['id'] > max_id:
                    max_id = p_dict['id']
            new_id = max_id + 1 # New ID is one greater than the current max
        
        # Create the new product dictionary
        new_product = {
            'id': new_id,
            'name': product_name,
            'brand': product_brand,
            'stock': product_stock,
            'cost': product_cost,
            'origin': product_origin
        }
        products_data.append(new_product) # Add to the main list of products
        print("Product '" + product_name + "' successfully added to inventory with ID " + str(new_id) + ".")
    except Exception as e: # Catch any other unexpected error
        print("An error occurred while adding the new product: " + str(e))
        print("Product not added. Please try again.")
