# read.py

# This module is responsible for all operations related to reading data 
# from external files, specifically the product inventory file.

# <----------------------------- Load Products with Auto ID -------------------->
def load_products_from_file(filename):
    """
    Loads product data from a specified text file.

    The function expects each line in the file to be comma-space separated
    and in the format: Product Name, Brand, Stock Quantity, Cost Price, Origin Country.
    It automatically assigns a unique integer ID to each product, starting from 101.
    This ID is used internally by the program and is not stored in the text file.

    Error Handling:
    - If the specified file is not found, a FileNotFoundError is caught, an error
      message is printed, and an empty list is returned.
    - If a line in the file does not have exactly 5 parts after splitting, or if
      stock/cost cannot be converted to the correct numeric type, a warning is
      printed, and that specific line is skipped.
    - Any other unexpected errors during file reading are also caught and reported.

    Newline Character Removal:
    - The function manually removes a trailing newline character ('\n') from the
      last field (origin) if it exists, avoiding the use of .strip().

    Args:
        filename (str): The name (and path, if not in the same directory) of the
                        text file containing the product data.

    Returns:
        list: A list of dictionaries. Each dictionary represents a product and
              contains the following keys:
              'id' (int): The auto-generated unique product ID.
              'name' (str): The name of the product.
              'brand' (str): The brand of the product.
              'stock' (int): The current stock quantity.
              'cost' (float): The cost price of the product to the shop.
              'origin' (str): The country of origin of the product.
              Returns an empty list if the file is not found or if critical errors occur
              during processing.
    """
    products = []  # Initialize an empty list to store product dictionaries
    current_product_id = 101  # Starting ID for the first product loaded

    try:
        # Attempt to open the file in read mode ('r')
        file_handle = open(filename, 'r')
        lines = file_handle.readlines()  # Read all lines from the file into a list
        file_handle.close()  # Always close the file after operations are complete

        # Iterate over each line read from the file
        for line_content in lines:
            # Split the line by ", " (comma followed by a space) to get individual parts.
            # This assumes a specific delimiter. If the delimiter is just a comma,
            # this would need to be changed to line_content.split(',')
            parts = line_content.split(', ')
            
            # Check if the line has the expected number of parts (5 for product data)
            if len(parts) == 5:
                # Assign parts to meaningful variable names
                product_name = parts[0]
                product_brand = parts[1]
                
                # Try to convert stock and cost to their appropriate numeric types.
                # This is a common place for errors if the file data is not clean.
                try:
                    product_stock = int(parts[2])    # Stock should be an integer
                    product_cost = float(parts[3])   # Cost can be a float
                except ValueError:
                    # If conversion fails, print a warning and skip this malformed line.
                    print("Warning: Skipping line due to invalid stock or cost format: " + line_content)
                    continue # Move to the next line in the file

                product_origin = parts[4] # The last part is the origin

                # Manually remove the newline character from the 'origin' string if present.
                # This is done because readlines() typically includes the newline at the end of each line.
                if len(product_origin) > 0 and product_origin[-1] == '\n':
                    product_origin = product_origin[:-1] # Slice the string to exclude the last character

                # Create a dictionary for the current product
                product_dictionary = {
                    'id': current_product_id,
                    'name': product_name,
                    'brand': product_brand,
                    'stock': product_stock,
                    'cost': product_cost,
                    'origin': product_origin
                }
                products.append(product_dictionary) # Add the product dictionary to the list
                current_product_id += 1  # Increment the ID for the next product
            else:
                # If a line doesn't have 5 parts, it might be an empty line or a malformed one.
                # Avoid printing warnings for completely empty lines.
                if line_content != '\n' and len(line_content) > 0 : 
                     print("Warning: Skipping malformed line in product file: " + line_content)

    except FileNotFoundError:
        # If the file does not exist, inform the user.
        print("Error: The product file ('" + filename + "') was not found.")
        print("Please ensure the file exists in the same directory as the program or provide the correct path.")
    except Exception as e:
        # Catch any other unexpected errors that might occur during file processing.
        print("An unexpected error occurred while reading the product file: " + str(e))
        
    return products # Return the list of loaded products (or an empty list on error)
