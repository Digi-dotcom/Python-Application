# main.py

# This is the main executable file for the WeCare Inventory System.
# It orchestrates the program flow by:
# 1. Importing necessary functions from other modules (read, write, operations).
# 2. Defining the global filename for product data.
# 3. Implementing the main program loop and submenus.

import read       # For loading product data from file
import write      # For saving product data and invoices
import operations # For core business logic (sales, restock, display, add product)

# Define the name of the product data file. This is used throughout the program.
PRODUCT_DATA_FILE = "products.txt"

# <-------------------- Main Program Loop -------------------->
def main_program_loop():
    """
    The main function that drives the WeCare Inventory System.

    Logic:
    1. Calls `read.load_products_from_file` to load initial product data into memory.
       This `current_products` list is then passed to and modified by other functions.
    2. Enters a `while True` loop to continuously display the main menu until the user chooses to exit.
    3. Main Menu Options:
       - "1. Make a Sale to Customer":
         - Checks if products are available.
         - Calls `operations.process_customer_sale` to handle the sale.
         - Calls `write.save_products_to_file` to update the inventory file after the sale
           (as stock levels change).
       - "2. Manage Inventory":
         - Calls the `manage_inventory_submenu`.
         - Calls `write.save_products_to_file` after returning from the submenu,
           as inventory operations (restock, add new) modify product data.
       - "3. Exit System":
         - Prints a goodbye message.
         - Calls `write.save_products_to_file` one last time to ensure all changes
           are saved before exiting.
         - Breaks the main loop to terminate the program.
    4. Handles invalid menu choices by printing an error message.
    """
    # Load product data from the text file when the program starts.
    # This list `current_products` will hold the state of the inventory in memory.
    current_products = read.load_products_from_file(PRODUCT_DATA_FILE)

    # The main loop for the program's menu system.
    while True:
        print("\n======= Welcome To WeCare Inventory System! =======")
        print("1. Make a Sale to Customer")
        print("2. Manage Inventory")
        print("3. Exit System")
        
        user_choice = input("Please enter your choice (1-3): ")

        if user_choice == '1':
            # Process a customer sale
            if not current_products: # Check if there are any products to sell
                print("No products available in inventory to sell. Please add or restock products first.")
            else:
                operations.process_customer_sale(current_products)
                # Important: Save changes to the product file after a sale
                write.save_products_to_file(current_products, PRODUCT_DATA_FILE)
        
        elif user_choice == '2':
            # Go to the inventory management submenu
            manage_inventory_submenu(current_products)
            # Important: Save changes after inventory management operations
            # (Restock or Add New Product might have changed the data)
            write.save_products_to_file(current_products, PRODUCT_DATA_FILE)

        elif user_choice == '3':
            # Exit the program
            print("\nThank you for using the WeCare Inventory System. Goodbye!")
            # Ensure any final changes are saved before exiting
            write.save_products_to_file(current_products, PRODUCT_DATA_FILE)
            break # Exit the while loop, terminating the program
        
        else:
            # Handle invalid input from the user
            print("Invalid choice. Please enter a number between 1 and 3.")

# <-------------------- Inventory Management Submenu -------------------->
def manage_inventory_submenu(products_list_ref):
    """
    Displays and handles the options within the Inventory Management submenu.

    Logic:
    1. Enters a `while True` loop for the submenu.
    2. Submenu Options:
       - "1. Restock Existing Products":
         - Checks if products exist to be restocked.
         - Calls `operations.process_shop_restock`.
       - "2. Add New Product to Inventory":
         - Calls `operations.add_new_product_to_inventory`.
       - "3. Return to Main Menu":
         - Breaks the submenu loop, returning control to the `main_program_loop`.
    3. Handles invalid submenu choices.

    Args:
        products_list_ref (list): A reference to the main list of product
                                  dictionaries. This allows functions called
                                  from this submenu to modify the actual product data.
    """
    while True:
        print("\n--- Inventory Management ---")
        print("1. Restock Existing Products")
        print("2. Add New Product to Inventory")
        print("3. Return to Main Menu")
        
        sub_choice = input("Please choose an option (1-3): ")

        if sub_choice == '1':
            # Restock existing products
            if not products_list_ref: # Check if there are any products to restock
                print("No products available to restock. Please add a new product first.")
            else:
                operations.process_shop_restock(products_list_ref)
        elif sub_choice == '2':
            # Add a new product to the inventory
            operations.add_new_product_to_inventory(products_list_ref)
        elif sub_choice == '3':
            # Return to the main menu
            break # Exit the submenu loop
        else:
            # Handle invalid input for the submenu
            print("Invalid choice. Please enter a number between 1 and 3.")


# <-------------------- Run Main Program -------------------->
# This standard Python construct ensures that `main_program_loop()` is called
# only when this script (`main.py`) is executed directly (not when it's imported as a module).
if __name__ == "__main__":
    main_program_loop()
