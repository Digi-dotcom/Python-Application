# write.py

# This module handles all operations related to writing data to files.
# This includes saving the updated product inventory and generating transaction invoices.

# <-------------------- Save Updated Products to File -------------------->
def save_products_to_file(products_list, filename):
    """
    Saves the current list of products back to the specified text file.

    Each product dictionary in the `products_list` is converted into a
    comma-space separated string in the format:
    Product Name, Brand, Stock Quantity, Cost Price, Origin Country
    This string is then written as a new line in the file.
    The function overwrites the existing file with the new data.

    Error Handling:
    - If an IOError occurs (e.g., permission issues, disk full), an error
      message is printed.
    - Any other unexpected errors during file writing are also caught and reported.

    Args:
        products_list (list): A list of product dictionaries that needs to be saved.
        filename (str): The name of the file where the product data will be saved.
    """
    try:
        # Open the file in write mode ('w'). This will create the file if it
        # doesn't exist, or truncate (empty) it if it does.
        file_handle = open(filename, 'w')
        
        # Iterate over each product dictionary in the provided list
        for product in products_list:
            # Construct the string to write for each product.
            # Ensure that numeric types (stock, cost) are converted to strings
            # before concatenation.
            line_to_write = product['name'] + ", " + \
                            product['brand'] + ", " + \
                            str(product['stock']) + ", " + \
                            str(product['cost']) + ", " + \
                            product['origin'] + "\n" # Add a newline character for the next entry
            file_handle.write(line_to_write) # Write the constructed line to the file
            
        file_handle.close() # Always close the file after writing is complete
    except IOError:
        # Handle errors related to file input/output operations.
        print("Error: Could not write to the product file ('" + filename + "'). Check permissions or disk space.")
    except Exception as e:
        # Catch any other unexpected errors.
        print("An unexpected error occurred while saving products: " + str(e))

# <-------------------- Generate and Save Transaction Invoice -------------------->
def generate_transaction_invoice(invoice_filename, invoice_content_lines):
    """
    Creates and saves a transaction invoice to a new text file.

    The content of the invoice is provided as a list of strings, where each
    string represents one line of the invoice. This function simply writes
    these lines to the specified file.

    Error Handling:
    - If an IOError occurs during file writing, an error message is printed.
    - Any other unexpected errors are also caught and reported.

    Args:
        invoice_filename (str): The unique name for the invoice file (e.g., including
                                customer name and timestamp).
        invoice_content_lines (list): A list of strings, with each string being a
                                      pre-formatted line for the invoice.
    """
    try:
        # Open the specified file in write mode ('w') to create the new invoice file.
        file_handle = open(invoice_filename, 'w')
        
        # Iterate through each line provided in the invoice_content_lines list
        for line in invoice_content_lines:
            file_handle.write(line + "\n") # Write the line followed by a newline character
            
        file_handle.close() # Close the invoice file
        print("\nInvoice successfully saved as: " + invoice_filename)
    except IOError:
        # Handle file writing errors.
        print("\nError: Could not write the invoice to file ('" + invoice_filename + "').")
    except Exception as e:
        # Catch any other unexpected errors.
        print("An unexpected error occurred while generating the invoice: " + str(e))
